﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ISIT328.Models
{
    public class CredentialModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
