﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ISIT328.Models;
using Microsoft.Extensions.Configuration;
using ISIT328.DAL;
using ISIT328.Models;

namespace ISIT328.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _configuration = config;
            _logger = logger;
        }

        public IActionResult Index(CredentialModel cm)
        {
            // everything is fine here. No need to change anything here
            DALPerson pd = new DALPerson(this._configuration);
            LinkedList<PersonModel> allPerson = pd.GetAllPerson();
            ViewBag.AllPerson = allPerson;

            return View();
        }

        
        public IActionResult UserLogin(CredentialModel cm)
        {
            // just get the info to display all users
            DALPerson pd = new DALPerson(this._configuration);
            LinkedList<PersonModel> allPerson = pd.GetAllPerson();
            ViewBag.AllPerson = allPerson;


            // everything is fine here. No need to change anything here
            PersonModel pm = pd.CheckLoginCredentials(cm);
            if (pm == null)
            {
                ViewBag.LoginStatus = "Login Failed!!";
            }
            else
            {
                ViewBag.LoginStatus = "Login Succeeded";
            }
            return View("Index");
        }
    }
}
